<?php

echo "Welcome to vagrant box...<br ><br >";

phpinfo();
?>
